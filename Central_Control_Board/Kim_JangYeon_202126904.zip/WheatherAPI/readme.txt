this Wheather.c is assuming that Wheather API. 
this program communicate with central.c by socket communication assuming that webSocket.