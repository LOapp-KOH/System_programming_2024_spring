main code: Central_Main, Excute file: central.
you should connect by socket communication in order of (0: Sensing Board, 1: Operation Board, 2: WeatherAPI)
please excute 1)this board - central  ==> 2) Sensing Board - main ==> 3) operation board - actuabor
 ==> 4)this board - WeatherAPI - whe